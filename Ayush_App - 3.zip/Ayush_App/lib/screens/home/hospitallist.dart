import 'package:ayush_app/screens/home/appointment.dart';
import 'package:ayush_app/screens/home/map.dart';
import 'package:customize/customize.dart';
import 'package:flutter/material.dart';

class SearchResults extends StatefulWidget {
  const SearchResults({Key? key}) : super(key: key);

  @override
  _SearchResultsState createState() => _SearchResultsState();
}

class _SearchResultsState extends State<SearchResults> {

  List <String> q = [
    'Aayush multy specality homeo clinic',
    'Ayush eva ayurvedic clinic',
    'Coimbatore Ayush Medical Centre',
    'Ayush child care',
    'Ayush Child Care Clinic'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: Colors.amber[600],
        title: const Text(
          'Search Results',
          style: TextStyle(
            color: Colors.black87,
          ),
        ),
      ),



      body: Container(
        child: Card(
          margin:  EdgeInsets.all(20),
          color: Colors.amber[200],
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children:  q.map((quote) => Text('👉🏿 $quote \n\n')).toList(),
    ),
                TextButton.icon(
                    onPressed: (){
                         Navigator.of(context).push(MaterialPageRoute(builder: (context) => const MapPage())) ;
                         } ,
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(FxColors.amber600)
                    ),
                    icon: const Icon(Icons.location_on,color: Colors.white,),
                    label: const Text('Show Map',
                    style: TextStyle(color: Colors.white),)),

              ElevatedButton(
                  onPressed: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => const Appointmentbooking())) ;
                  } ,
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(FxColors.amber600)
                    ),
                  child: const Text('Book an Appontment'),
              )
              ],

            ),
          ),
        ),
      ),
    );;
  }
}
