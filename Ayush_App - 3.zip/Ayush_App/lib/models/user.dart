class UserCls{

final String uid ;

UserCls({ required this.uid });

}