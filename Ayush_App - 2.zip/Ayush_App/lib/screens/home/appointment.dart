import 'package:customize/customize.dart';
import 'package:flutter/material.dart';
import '../../additional files/constants.dart';

class Appointmentbooking extends StatefulWidget {
  const Appointmentbooking({Key? key}) : super(key: key);

  @override
  _AppointmentbookingState createState() => _AppointmentbookingState();
}

class _AppointmentbookingState extends State<Appointmentbooking> {

  void _showAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) => const AlertDialog(
          title: Text("Wifi"),
          content: Text("Wifi not detected. Please activate it."),
        )
    );
  }

  var items = ['Select Doctor','Dr. Dhanush - Ayurveda ','Dr. Kannan - Yoga','Dr. Babu - Siddha','Dr. Krishna - Unani','Dr. Maha - Homeopathy'] ;
  String _currentSugars = '';


  @override
  Widget build(BuildContext context) {

    // _showAlert(context);
    return Scaffold(

      backgroundColor: FxColors.amber100 ,

      appBar: AppBar(
        backgroundColor: FxColors.amber500 ,
        elevation: 0.0,
        title: const Text(
          'Appointment Booking',
          style: TextStyle(
            color: Colors.black87,
          ),
        ),


      ),

      body: Container(

          padding: const EdgeInsets.symmetric(vertical: 20 , horizontal: 50 ),

          child: Form(

              child: Column(

                children:  <Widget>[

                  const SizedBox( height: 20,),
                  TextFormField(
                    decoration: textInputDecoration.copyWith(
                        hintText: 'Patient Name',
                        prefixIcon: const Icon(Icons.person)
                    ) ,

                    validator: (val) => val!.isEmpty ? 'Enter your Name' : null  ,
                  ),

                  const SizedBox( height: 20,),
                  TextFormField(
                    decoration: textInputDecoration.copyWith(
                        hintText: 'Contact Number',
                        prefixIcon: const Icon(Icons.call)
                    ) ,

                    validator: (val) => val!.length != 10 ? 'Enter an valid Mobile number' : null ,

                  ),

                  const SizedBox( height: 20,),
                  TextFormField(
                    maxLines: 4 ,
                    decoration: textInputDecoration.copyWith(
                        hintText: 'Address',
                        prefixIcon: const Icon(Icons.home),
                    ) ,

                    validator: (val) => val!.isEmpty ? 'Enter your Address' : null  ,

                  ),

                  // PASSWORD
                  const SizedBox( height: 20,),
                  TextFormField(
                    maxLines: 2,
                    decoration: textInputDecoration.copyWith(
                        hintText: 'Health Problems\n'
                                  'eg: Cold , fever ,...',
                        prefixIcon: const Icon(Icons.local_hospital)
                    ) ,

                    validator: (val) => val!.length < 6 ? 'Enter an valid Password above 6 chars' : null ,


                  ),

                  const SizedBox( height: 20,),

                  DropdownButtonFormField<String>(
                    dropdownColor: Colors.amber,
                    value: 'Select Doctor' ,
                    onChanged:  (val) => setState(() => _currentSugars = val! ) ,
                    decoration: textInputDecoration,
                    items: items.map((e) => DropdownMenuItem<String>(value: e,child: Text(e)) ).toList(),

                  ),

                  const SizedBox( height: 20,),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: FxColors.amber600,
                    ),
                    onPressed: () {},

                    child: const Text(
                      'Book',
                      style: TextStyle(
                        color: Colors.white ,
                        fontSize: 18 ,
                      ),
                    ),
                  ),

                ],
              )

          )
      ),
    );
  }
}
