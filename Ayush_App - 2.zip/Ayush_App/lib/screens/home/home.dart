import 'package:ayush_app/screens/home/hospitallist.dart';
import 'package:ayush_app/screens/home/map.dart';
import 'package:flutter/material.dart';
import '../../additional files/constants.dart';
import '../../services/auth.dart';


class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {

  final AuthService _auth = AuthService();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amber[100],

      appBar: AppBar(
        backgroundColor: Colors.amber[600],
        title: const Text(
          'Ayush',
          style: TextStyle(
            color: Colors.black87,
          ),
        ),
        elevation: 0.0,
        actions: <Widget>[
          TextButton.icon(

            onPressed: () async {
              await _auth.signOut();
            },

            icon: const Icon(
              Icons.person,
              color: Colors.black87,
            ),

            label: const Text(
              'Log Out',
              style: TextStyle(
                color: Colors.black87,
              ),
            ),
          )
        ],
      ),

      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(

            children: <Widget> [

              const SizedBox( height: 20,),
              TextFormField(
                decoration: textInputDecoration.copyWith(
                    hintText: 'Enter Location',
                    prefixIcon: const Icon(Icons.location_on)
                ) ,

                validator: (val) => val!.isEmpty ? 'Enter An Location' : null  ,
              ),

              const SizedBox( height: 20,),

              Container(
                color: Colors.amber,

                child: TextButton.icon(
                  onPressed: () {
                    if(_formKey.currentState!.validate()){
                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => const SearchResults())) ;
                    }
                    } ,
                    label: const Text(
                      'Search',
                      style: TextStyle(
                        color: Colors.black87,
                      ),
                  ),
                  icon: const Icon(
                      Icons.search,
                      color: Colors.black87,
                  ),

                ),
              ),

            ],
          ),
        ),
      ),

     );
  }



}
